function [z] = func_fl(sym_x)
%% Jacobian(f(x))
z= [1/10, 1 - sin(sym_x(2)/10)/10;
    0,             49/50];
end


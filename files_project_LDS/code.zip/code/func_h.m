function [z] = func_h(sym_x)
%% h(x)
z= (sym_x(2))^2 - sym_x(2) -(sym_x(1))^2 + sym_x(1);
end

